<div class="container mt-3">
    <h5 class="fw-bold ms-2">Activity Tracker</h5>
    <small class="text-muted ms-2 mb-3 d-block">All View</small>

    <?php if($habits->isEmpty()): ?>
        <div class="alert alert-info text-center">
            <i class="bi bi-info-circle-fill"></i> No habits found for this day.
        </div>
    <?php else: ?>
        <div class="habit-list">
            <?php $__currentLoopData = ['Family', 'Health', 'Money', 'Self Care', 'Home Care', 'Goals', 'Time']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $filteredHabits = $habits->where('category', $category);
                    $iconEmoji = match($category) {
                        'Family' => '🧑‍🤝‍🧑',
                        'Health' => '🫀',
                        'Money' => '💰',
                        'Self Care' => '😊',
                        'Home Care' => '🧼',
                        'Goals' => '🎯',
                        'Time' => '⏰',
                        default => '📌'
                    };
                ?>
                <div class="rounded-pill-row">
                    <div class="category-title d-flex align-items-center justify-content-between" onclick="toggleCollapse('<?php echo e(Str::slug($category)); ?>')">
                        <div class="d-flex align-items-center">
                            <span class="emoji me-2"><?php echo e($iconEmoji); ?></span>    
                            <span class="fw-semibold"><?php echo e($category); ?></span>
                        </div>
                        <i class="bi bi-chevron-down" id="icon-<?php echo e(Str::slug($category)); ?>"></i>
                    </div>
                    <div id="collapse<?php echo e(Str::slug($category)); ?>" class="collapse">
                        <ul class="dots-row">
                        <?php if($filteredHabits->isEmpty()): ?>
                            <li class="">No habits in this category</li>
                        <?php else: ?>
                            <?php $__currentLoopData = $filteredHabits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $habit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class=" dot filled" ><?php echo e($habit->name); ?> | <?php echo e(date('g:i A', strtotime($habit->start_time))); ?> - <?php echo e(date('g:i A', strtotime($habit->end_time))); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </ul>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<script>
    function toggleCollapse(id) {
        const target = document.getElementById('collapse' + id);
        const icon = document.getElementById('icon-' + id);
        const isOpen = target.classList.contains('show');

        document.querySelectorAll('.collapse').forEach(el => el.classList.remove('show'));
        document.querySelectorAll('.bi-chevron-up, .bi-chevron-down').forEach(el => el.classList.replace('bi-chevron-up', 'bi-chevron-down'));

        if (!isOpen) {
            target.classList.add('show');
            icon.classList.replace('bi-chevron-down', 'bi-chevron-up');
        }
    }
</script>

<style>
.container {
    border-radius: 25px;
    padding: 20px;
    background-color: #fff;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
}

.habit-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.rounded-pill-row {
    background-color: #fafafa;
    border-radius: 20px;
    padding: 12px 15px;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
    cursor: pointer;
    border: 1px solid #e0e0e0;
}

.category-title {
    font-size: 1rem;
    display: flex;
    align-items: center;
    font-weight: 600;
    color: #333;
    justify-content: space-between;

}

.emoji {
    font-size: 1.4rem;
}

.dots-row {
    display: flex;
    flex-direction: column; 
    gap: 8px;
    padding: 10px 0 0 10px;
    margin: 0;
    list-style: none;
}

.dot {
    background-color: transparent; 
    color: #333;
    font-size: 0.95rem;
    position: relative;
    padding-left: 20px;
}

.dot::before {
    content: '●';
    color: #198754;
    position: absolute;
    left: 0;
    top: 0;
    font-size: 1rem;
    line-height: 1.2;
}


/* .dot.filled {
    background-color: #198754;
} */


.collapse {
    display: none;
}

.collapse.show {
    display: flex;
    flex-direction: column;
}

h5.fw-bold {
    font-size: 1.2rem;
    margin-bottom: 5px;
}

small.text-muted {
    font-size: 0.9rem;
    margin-bottom: 15px;
    display: block;
}

.bi {
    font-size: 1rem;
    color: #888;
}
</style>

<?php echo $__env->make('components.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\goFam\resources\views/habit-tracker.blade.php ENDPATH**/ ?>